# Senior Project

<h5>Encryption Standards</h5>

<h6>Resources</h6>
<ul>
  <li><a href="https://www.movable-type.co.uk/scripts/sha1.html">Sha-1</a></li>
  <li><a href="https://eloquentjavascript.net/">Eloquent JavaScript</a></li>
  <li><a href="http://exploringjs.com/impatient-js/index.html">Impatient JavaScript</a></li>
</ul>
